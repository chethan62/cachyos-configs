#!/bin/bash

exec bash $@
